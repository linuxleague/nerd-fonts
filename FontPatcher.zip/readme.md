
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 75f785402d5610df582ddcc7e68f3bd504f86dd2
        Author: Finii <Finii@users.noreply.github.com>
        Date:   Mon Sep 18 09:16:09 2023 +0000
        
            [ci] Update FontPatcher.zip
